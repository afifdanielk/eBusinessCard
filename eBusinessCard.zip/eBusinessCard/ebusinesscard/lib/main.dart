import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';  // Import the qr_flutter package for QR code generation

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Profile App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const ProfileScreen(),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Profile link (use dynamic or hardcoded link for each user's profile)
    String profileLink = 'https://example.com/profile'; // Replace with your actual profile link

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,  // Center content vertically
            children: [
              Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.grey[300],  // Grey background for profile box
                  borderRadius: BorderRadius.circular(12),  // Rounded corners
                ),
                child: Column(
                  children: [
                    const CircleAvatar(
                      radius: 50,
                      backgroundImage: AssetImage('assets/afif.jpg'), // Placeholder image
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Ahmad Afif Daniel',
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      'afifdanielk@gmail.com',
                      style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Job Title: PROTEGE Digital Technology',
                      style: TextStyle(fontSize: 16),
                    ),
                    Text(
                      'Business Name: Sime Darby Auto Bavaria Sdn Bhd',
                      style: TextStyle(fontSize: 16),
                    ),
                    Text(
                      'Mobile No: 013-4440024',
                      style: TextStyle(fontSize: 16),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  // Print the profile link to console (share functionality can be added here)
                  print('Profile link: $profileLink');
                },
                child: const Text('Share Profile'),
              ),
              const SizedBox(height: 24),
              // Clickable QR Image (The QR code itself will act as a button)
              GestureDetector(
                onTap: () {
                  _showQRCodeDialog(context, profileLink);
                },
                child: QrImageView(
                  data: profileLink,  // Profile link for the QR code
                  version: QrVersions.auto,
                  size: 150.0,  // Adjust size to make it clickable
                  foregroundColor: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Function to show QR code in a dialog
  void _showQRCodeDialog(BuildContext context, String profileLink) {
    showDialog(
      context: context,
      barrierDismissible: true, // Allows dismissing the dialog by tapping outside
      barrierColor: Colors.black.withOpacity(0.5), // Lightly darkens the background behind the dialog
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,  // Transparent background for the dialog
          child: GestureDetector(
            onTap: () {
              Navigator.of(context).pop(); // Close the dialog when tapping outside the QR code
            },
            child: Center(
              child: Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 255, 255, 255),  // Grey background for the QR code box
                  borderRadius: BorderRadius.circular(12),  // Rounded corners
                ),
                child: QrImageView(
                  data: profileLink,  // Profile link for the QR code
                  version: QrVersions.auto,
                  size: 250.0,
                  foregroundColor: Colors.black,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
